0. You can use SQL Manager (Chrome/Edge/Brave Extension):
https://webextension.org/listing/sqlite-manager.html

1. You can also try out the official command-line environment:
https://www.sqlite.org/download.html
1a. >sqlite3 2_papers.sqlite
1b. >.tables (for seeing all the tables)
1c. >.schema refs (for seeing all the columns)
1d. >select * from refs (for seeing all the data)
