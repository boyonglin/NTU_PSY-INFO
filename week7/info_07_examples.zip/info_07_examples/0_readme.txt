[Node.js]
npm install express cors
node 2_hello.js

[FastAPI]
pip install fastapi uvicorn
uvicorn 5_hello:app --reload
See http://localhost:8000/docs for available APIs
